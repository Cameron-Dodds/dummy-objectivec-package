//
//  Protection.h
//  dummy-objectivec-package
//
//  Created by Cameron Dodds on 22/11/2022.
//

@interface Protection : NSObject

- (NSString *)getToken;

@end
