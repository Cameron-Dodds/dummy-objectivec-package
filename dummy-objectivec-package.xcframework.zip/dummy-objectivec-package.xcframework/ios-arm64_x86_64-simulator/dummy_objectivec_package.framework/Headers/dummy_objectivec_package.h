//
//  dummy_objectivec_package.h
//  dummy-objectivec-package
//
//  Created by Cameron Dodds on 22/11/2022.
//

#import <Foundation/Foundation.h>
#import <Protection.h>
//! Project version number for dummy_objectivec_package.
FOUNDATION_EXPORT double dummy_objectivec_packageVersionNumber;

//! Project version string for dummy_objectivec_package.
FOUNDATION_EXPORT const unsigned char dummy_objectivec_packageVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <dummy_objectivec_package/PublicHeader.h>


